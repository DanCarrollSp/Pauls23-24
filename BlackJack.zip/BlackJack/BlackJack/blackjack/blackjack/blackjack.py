import random
import time
import os

from rich import print
from rich.console import Console

console = Console()

## import data  # Makes sure you put data. in front of all function calls.

from model.data import make_deck, init_deck_values
from calcs import calc_total, determine_ace_value
from view.ui import display_cards

def clear(): os.system('cls')

def play():

    clear()
    console.print("Game start! Good Luck!", style="bold underline yellow")

    deck_values = init_deck_values()


    def draw():
        """Select a random card from the deck. The deck shrinks by 1."""
        selection = random.choice(deck)
        deck.remove(selection)
        return selection, deck_values[selection]


    def display_status():
        return f"""
        Here are your cards: {display_cards(player)}
        Score: {calc_total(player)}

        Here is the dealer's card: {dealer[0][0]}

        What's next?  Hit or Stand? 
        """  

    def add_card(who):
        """Given a player or dealer list, add another card to the list."""
        selection = draw()
        if isinstance(selection[-1], list):
            who.append((selection[0], determine_ace_value(who)))  # We have an Ace.
        else:
            who.append(selection)    


    deck = make_deck()


    player = []
    dealer = []

    player.append(draw())
    dealer.append(draw())
    player.append(draw())
    dealer.append(draw())


    if __name__ == "__main__":   # Is Python running directly (or imported)?

        while True:
            print(display_status())
            console.print("Press 'h' or 's' to continue!\n", style="bold underline yellow")
            choice = input()
            clear()

            if choice in ['h', 'H']:
                add_card(player)
                if calc_total(player) >= 21 :
                    break
            elif choice in ['s', 'S']:
                break
            else:
                console.print("Whoops! That's not an option here. Please choose 'h' or 's'.", style="bold underline yellow")

        keep_playing = True
        if calc_total(player) > 21:
            print(display_status())
            clear()
            print("Your score is over 21. You're busted!")
            keep_playing = False
        elif calc_total(player) == 21:
            if(calc_total(player) != calc_total(dealer)):
                clear()
                console.print("Congrats! You WIN with a score of 21!", style="bold green")
        else:
            print("Current state of game:")
            print(display_status())
            clear()

        if keep_playing:
            while True:
                if calc_total(dealer) >= 17:
                    break
                add_card(dealer)
                if calc_total(dealer) > 21:
                    clear()
                    console.print("You Win! Dealer busted!", style="bold green")
                    break
                elif calc_total(dealer) >= 17:
                    break
        else:
            clear()
            print("Dealer wins.")

        ##Displaying who won when game ended when a player stands
        if (calc_total(player) == calc_total(dealer)):
            clear()
            console.print("Draw!", style="bold underline yellow")
        if (calc_total(player) > calc_total(dealer)):
            if( calc_total(player) < 21):
                console.print("You Win!", style="bold green")
        if (calc_total(player) < calc_total(dealer) & calc_total(dealer) < 22):
            console.print("You Lose, Dealer Wins!", style="bold red")

        ##Outputs final values
        print("\nPlayer:", display_cards(player), "\nworth ", calc_total(player))
        print("\nDealer:", display_cards(dealer), "\nworth ", calc_total(dealer))


        console.print("\nGame Over! Press Enter to Play again!", style="bold underline yellow")
        input()
        play()##Loads next game

play()##Loads first gane